// Design: Editorial Minimalism — User-provided office image with logo & slogan on wall
// Image already contains KONTA logo and English slogan — display as-is, no overlay text

const HERO_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663333770398/ZgHnYJz9Mp4Eb2ccWUmBVo/main_8bfec0aa.png";

export default function HeroSection() {
  return (
    <section id="hero" className="relative overflow-hidden" style={{ minHeight: "100vh", height: "auto", aspectRatio: "auto" }}>

      {/* ── Full-screen background image ── */}
      <div
        className="absolute inset-0 w-full"
        style={{
          backgroundImage: `url(${HERO_IMG})`,
          backgroundSize: "cover",
          backgroundPosition: "center top",
          backgroundRepeat: "no-repeat",
          minHeight: "100vh",
          height: "100%",
          width: "100%",
        }}
      />

      {/* Bottom address bar */}
      <div className="absolute bottom-0 left-0 right-0 z-10 border-t border-black/10 px-3 md:px-10 lg:px-16 py-2 md:py-2.5 flex items-center bg-white/40 backdrop-blur-md">
        <span className="font-['Noto_Sans_JP'] text-[0.55rem] sm:text-[0.6rem] md:text-[0.75rem] text-[#1a1a1a]/60 tracking-wider truncate">
          〒101-0051 東京都千代田区神田神保町2-12-3 L&Kビル 7階
        </span>
      </div>
    </section>
  );
}
