// Design: Editorial Minimalism
// UPDATED v17: Mobile-optimized photo display with better text sizing
// Photo fills the left column fully, full-body visible, balanced with text

import { useEffect, useRef } from "react";

const CHAIRMAN_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663333770398/ZgHnYJz9Mp4Eb2ccWUmBVo/chairman_d062dffa.png";

function useReveal(delay = 0) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.style.opacity = "0";
    el.style.transform = "translateY(20px)";
    el.style.transition = `opacity 0.9s cubic-bezier(0.16,1,0.3,1) ${delay}ms, transform 0.9s cubic-bezier(0.16,1,0.3,1) ${delay}ms`;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.style.opacity = "1";
          el.style.transform = "translateY(0)";
          obs.disconnect();
        }
      },
      { threshold: 0.08 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [delay]);
  return ref;
}

export default function MessageSection() {
  const photoRef = useReveal(0);
  const textRef = useReveal(120);

  return (
    <section id="message" className="bg-[#f5f5f3] overflow-hidden">

      {/* Section label */}
      <div className="px-6 md:px-10 lg:px-16 xl:px-20 pt-12 md:pt-16 pb-4">
        <span className="font-['Montserrat'] text-[0.65rem] tracking-[0.28em] text-[#1a1a1a]/50 uppercase font-semibold">
          Message
        </span>
      </div>

      {/*
        Layout strategy:
        - Outer flex row with items-stretch so both columns share the same height
        - Photo column: full width on mobile, ~38% on desktop
        - Text column: flex-1, padding on all sides, vertically centered content
      */}
      <div className="flex flex-col md:flex-row items-stretch">

        {/* ── Photo column ── */}
        <div
          ref={photoRef}
          className="w-full md:w-[38%] lg:w-[36%] shrink-0 relative"
          style={{ minHeight: "480px" }}
        >
          {/*
            Use absolute fill so the image column stretches to match text column height.
            object-contain + object-bottom keeps full body visible, bottom-aligned.
            On mobile, image is larger and more prominent with warm background.
          */}
          <div className="absolute inset-0 flex items-end justify-center overflow-hidden bg-[#ede9e3]">
            <img
              src={CHAIRMAN_IMG}
              alt="代表取締役 權容守"
              className="w-full h-full object-contain object-bottom sm:object-center"
              style={{ maxWidth: "100%" }}
            />
          </div>
        </div>

        {/* ── Text column ── */}
        <div
          ref={textRef}
          className="flex-1 flex flex-col justify-center px-4 sm:px-6 md:pl-8 lg:pl-12 xl:pl-14 pr-4 sm:pr-6 md:pr-8 lg:pr-12 xl:pr-16 py-6 sm:py-8 md:py-12 lg:py-16"
        >
          {/* Main heading */}
          <div className="mb-4 sm:mb-5">
            <p
              className="font-['Noto_Sans_JP'] font-bold text-[#1a1a1a] leading-[1.65]"
              style={{ fontSize: "clamp(0.95rem, 2vw, 1.3rem)" }}
            >
              株式会社權田は、モノを届ける企業ではなく、<br />
              ライフスタイルと価値を創造する企業へと進化してまいりました。
            </p>
          </div>

          {/* Short divider */}
          <div className="w-8 h-[2px] bg-[#1a1a1a]/30 mb-4 sm:mb-5" />

          {/* Body paragraphs */}
          <div className="space-y-3 sm:space-y-4 mb-6 sm:mb-8">
            <p className="font-['Noto_Sans_JP'] text-[0.75rem] sm:text-[0.82rem] font-normal text-[#1a1a1a]/65 leading-[1.95] sm:leading-[2.1] tracking-wide">
              これまで、化粧品セレクトショップ「cos:mura」を通じて、K-Beautyを日本の生活の中に届けてきた経験は、単なる商品流通にとどまらず、人々の価値観やライフスタイルに影響を与えるものであったと考えています。
            </p>
            <p className="font-['Noto_Sans_JP'] text-[0.75rem] sm:text-[0.82rem] font-normal text-[#1a1a1a]/65 leading-[1.95] sm:leading-[2.1] tracking-wide">
              これからの時代に求められるのは、モノの提供ではなく、体験やストーリー、そして共感です。株式会社權田は、ブランド、体験、そしてライフスタイルの価値を設計し、人と人、価値と価値をつなぐことで、新しい可能性を創造してまいります。
            </p>
            <p className="font-['Noto_Sans_JP'] text-[0.75rem] sm:text-[0.82rem] font-normal text-[#1a1a1a]/65 leading-[1.95] sm:leading-[2.1] tracking-wide">
              これからも時代の変化を捉えながら、社会とともに、新しい価値のかたちを創り続けてまいります。
            </p>
          </div>

          {/* Signature */}
          <div className="border-t border-[#dddad5] pt-3 sm:pt-4">
            <div className="flex flex-col items-end text-right gap-0.5 sm:gap-1">
              <span
                className="block font-['Cormorant_Garamond'] font-light text-[#1a1a1a] tracking-wide"
                style={{ fontSize: "clamp(1.5rem, 4vw, 2rem)" }}
              >
                權容守
              </span>
              <span className="block font-['Noto_Sans_JP'] text-[0.7rem] sm:text-[0.78rem] font-normal text-[#1a1a1a]/55 tracking-wider">
                <span className="block sm:inline">株式会社權田 代表取締役</span>
                <span className="hidden sm:inline">&nbsp;&nbsp;|&nbsp;&nbsp;</span>
                <span className="block sm:inline">韓国化粧品協会 会長</span>
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
